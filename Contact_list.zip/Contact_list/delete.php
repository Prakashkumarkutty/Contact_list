<?php 
    $host     = "localhost";
    $port     = 3306;
    $user     = "root";
    $password = "Prakash@32";
    $dbname   = "contact_list";

    $con = new mysqli($host, $user, $password, $dbname, $port, )
    or die ('Could not connect to the database server' . mysqli_connect_error());

    $userId = isset($_GET['id']) ? $_GET['id'] : 0;
    $userSql = "DELETE FROM contacts WHERE id = '$userId'";
    mysqli_query($con, $userSql);

    header('location: index.php');

?>