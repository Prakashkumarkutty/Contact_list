<?php 
    $host     = "localhost";
    $port     = 3306;
    $user     = "root";
    $password = "Prakash@32";
    $dbname   = "contact_list";

    $con = new mysqli($host, $user, $password, $dbname, $port, )
    or die ('Could not connect to the database server' . mysqli_connect_error());
    $sql ="SELECT * FROM contacts";
    $getUserData = mysqli_query($con, $sql);

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact List</title>
     <link rel="stylesheet" href="./assets/style.css">
</head>

<body>
    <div class="container">
        <h1>Contact List</h1>
        <div class="addBtn">
            <a href="addEdit.php" class="btn">Add Contact</a>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    while ($row = $getUserData->fetch_array(MYSQLI_BOTH)){
                        echo "<tr>";
                        echo "<td>" .$row['firstName']." ".$row['lastName']. "</td>";
                        echo "<td>".$row['email']."</td>";
                        echo "<td>"."<a href='addEdit.php?id=".$row["id"]."'>Edit</a>".
                        " | "."<a href='delete.php?id=".$row["id"]."' onclick='return confirmDelete()'>Delete</a>"."</td>";
                        echo "</tr>";
                    }                    
                ?>
            </tbody>
        </table>
    </div>

    <script>
        function confirmDelete() {
            return confirm("Are you sure you want to delete this item?");
        }
    </script>
</body>
</html>