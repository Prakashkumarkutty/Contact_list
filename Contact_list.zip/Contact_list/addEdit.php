<?php
    $host     = "localhost";
    $port     = 3306;
    $user     = "root";
    $password = "Prakash@32";
    $dbname   = "contact_list";

    $con = new mysqli($host, $user, $password, $dbname, $port, )
    or die ('Could not connect to the database server' . mysqli_connect_error());

    

    if ( isset($_GET['id']) ) {
        $userId =  $_GET['id'] ;
    } else {
        $userId = 0;
    }
    $userSql = "SELECT * FROM contacts WHERE id = '$userId'";
    $getUserDataById = mysqli_query($con, $userSql);
    $firstName = "";
    $lastName = "";
    $userEmail = "";
    $userPhone = "";
    if ($row = mysqli_fetch_assoc($getUserDataById)) {
        $firstName = $row['firstName'];
        $lastName = $row['lastName'];
        $userEmail = $row['email'];
        $userPhone = $row['mobileNumber'];
    }
    if(isset($_POST['submit'])){
        $fname = $_POST['firstName'];
        $lname = $_POST['lastName'];
        $email = $_POST['email'];
        $number= $_POST['mobileNumber'];
       

        if(isset($_GET['id'])) {
            $sql = "UPDATE contacts SET firstName = '$fname', lastName = '$lname' , 
            email = '$email', mobileNumber = '$number'
            WHERE id = $userId" ;
        } else {
            $sql = "INSERT INTO contacts (firstName, lastName, email, mobileNumber) 
            VALUES('$fname','$lname','$email','$number')";

        }
        if( mysqli_query($con, $sql) ) {
            header('location: index.php');
        } else {
            echo 'Some thing error' . $con->error;
        }
    }
?>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Contact Management</title>
        <link rel="stylesheet" href="css/styles.css">
    </head>
    <body>
        <div class="container">
            <h1>Contact Management</h1>
            <form id="contactForm" action="" method="POST" enctype="multipart/form-data">
                <label for="firstName">First Name:</label> 
                <input type="text" name="firstName" id="firstName" value="<?php echo $firstName?>" required><br><br>
                <label for="lastName">Last Name:</label>
                <input type="text" name="lastName" id="lastName" value="<?php echo $lastName?>" required><br><br>
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" value="<?php echo $userEmail?>" required><br><br>
                <label for="mobileNumber">Mobile Number:</label>
                <input type="text" name="mobileNumber" id="mobileNumber" value="<?php echo $userPhone?>" required><br><br>
                <input type="submit" value="<?php echo $userId != 0 ? 'Update' : 'Add' ?>" name="submit">

                <input type="reset" value="Reset" name="reset">
            </form>
        </div>
    </body>
</html>
